HUNTER FUN WORLD - TEST APK PROJECT

Build:
1. Extract this ZIP.
2. Open the extracted project root (the folder containing settings.gradle.kts).
3. Build with Gradle 8.9 and JDK 17:
   gradle assembleDebug

APK output:
app/build/outputs/apk/debug/app-debug.apk

Package: in.hunterfunworld.test
Version: 0.1
Minimum Android: 6.0 (API 23)

IMPORTANT:
This is a test/demo interface. Login, registration, tournaments, points,
notifications, support and admin/backend services are not connected yet.
Password validation requires at least 6 characters.
