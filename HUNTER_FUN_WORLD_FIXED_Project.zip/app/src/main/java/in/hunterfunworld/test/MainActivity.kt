package in.hunterfunworld.test

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val navy = Color.rgb(7, 13, 31)
    private val panel = Color.rgb(17, 29, 57)
    private val blue = Color.rgb(28, 119, 255)
    private val red = Color.rgb(255, 55, 78)
    private lateinit var username: EditText
    private lateinit var password: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        window.decorView.systemUiVisibility = 0

        val scroll = ScrollView(this).apply { setBackgroundColor(navy) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "HUNTER"
            textSize = 34f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }
        root.addView(brand, matchWrap())

        val subtitle = TextView(this).apply {
            text = "FUN WORLD  •  PLAY  •  COMPETE  •  CONNECT"
            textSize = 11f
            setTextColor(Color.rgb(145, 177, 225))
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(34)))

        val banner = TextView(this).apply {
            text = "WELCOME TO THE ARENA\nYour fun starts here."
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(panel, 18)
        }
        val bannerParams = LinearLayout.LayoutParams(-1, dp(112))
        bannerParams.topMargin = dp(18)
        root.addView(banner, bannerParams)

        val section = TextView(this).apply {
            text = "PLAYER LOGIN"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        val sectionParams = LinearLayout.LayoutParams(-1, dp(40))
        sectionParams.topMargin = dp(24)
        root.addView(section, sectionParams)

        username = field("Enter username")
        root.addView(username, fieldParams())
        password = field("Enter password").apply {
            inputType = 129
        }
        val passParams = fieldParams()
        passParams.topMargin = dp(12)
        root.addView(password, passParams)

        val login = actionButton("LOGIN", blue)
        val loginParams = LinearLayout.LayoutParams(-1, dp(52))
        loginParams.topMargin = dp(16)
        root.addView(login, loginParams)
        login.setOnClickListener {
            val user = username.text.toString().trim()
            val pass = password.text.toString()
            when {
                user.isEmpty() -> toast("Enter your username")
                pass.length < 6 -> toast("Password must be at least 6 characters")
                else -> toast("Demo login only. Online account system is not connected yet.")
            }
        }

        val register = actionButton("CREATE ACCOUNT", red)
        val regParams = LinearLayout.LayoutParams(-1, dp(50))
        regParams.topMargin = dp(10)
        root.addView(register, regParams)
        register.setOnClickListener { toast("Registration will be connected in the full version.") }

        addHeading(root, "EXPLORE HUNTER")
        addFeature(root, "BGMI TOURNAMENTS", "Discover upcoming community matches")
        addFeature(root, "GAMES & CHALLENGES", "Take part in fun activities")
        addFeature(root, "POINTS & LEADERBOARD", "Track demo points and rankings")
        addFeature(root, "COMMUNITY", "Connect with other players")
        addFeature(root, "ANNOUNCEMENTS", "Stay updated with notices")
        addFeature(root, "SUPPORT", "Contact the HUNTER team")

        val note = TextView(this).apply {
            text = "TEST BUILD 0.1  •  Demo interface only"
            textSize = 11f
            setTextColor(Color.rgb(130, 148, 180))
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, dp(8))
        }
        root.addView(note, matchWrap())
    }

    private fun addHeading(root: LinearLayout, title: String) {
        val tv = TextView(this).apply {
            text = title
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        val p = LinearLayout.LayoutParams(-1, dp(42))
        p.topMargin = dp(20)
        root.addView(tv, p)
    }

    private fun addFeature(root: LinearLayout, title: String, detail: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(13), dp(15), dp(13))
            background = rounded(panel, 14)
        }
        val heading = TextView(this).apply {
            text = title
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        val desc = TextView(this).apply {
            text = detail
            textSize = 12f
            setTextColor(Color.rgb(164, 183, 215))
            setPadding(0, dp(4), 0, 0)
        }
        box.addView(heading, matchWrap())
        box.addView(desc, matchWrap())
        val p = LinearLayout.LayoutParams(-1, -2)
        p.topMargin = dp(9)
        root.addView(box, p)
        box.setOnClickListener { toast("$title — demo screen") }
    }

    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.rgb(139, 157, 190))
        setTextColor(Color.WHITE)
        textSize = 14f
        singleLine = true
        setPadding(dp(15), 0, dp(15), 0)
        background = rounded(panel, 12)
    }

    private fun actionButton(label: String, color: Int) = Button(this).apply {
        text = label
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        isAllCaps = false
        background = rounded(color, 12)
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun fieldParams() = LinearLayout.LayoutParams(-1, dp(52))
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
